
public class LevelA_98 {
	public static void main(String args[]) {
		
		
		
	}
	
	 public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
	        
	 }
	 
	 public class ListNode {
		      int val;
		      ListNode next;
		      ListNode(int x) {
		          val = x;
		          next = null;
		      }
		  }

}
