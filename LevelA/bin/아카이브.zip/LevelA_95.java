
public class LevelA_95 {

}
