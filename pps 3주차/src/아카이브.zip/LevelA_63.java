
public class LevelA_63 {
	public static void main(String args[]) {
		String a = "11";
		String b = "1";
		String result = addBinary(a,b);
		System.out.println(result);
		
		
	}
	
	 public static String addBinary(String a, String b) {
		 String result="";
		 
	     
	 
		 return result;
	 }

}
